﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentalProject.Web.Utility
{
    public static class GlobalConfiguration
    {
        public const string StatusPending = "Pending";
        public const string StatusRefund = "Refunded";
        public const string StatusApproved = "Approved";
        public const string StatusCancelled = "Cancelled";
        public const string StatusInProcess = "UnderProcessing";
        public const string StatusShipped = "Shipped";

    }
}
