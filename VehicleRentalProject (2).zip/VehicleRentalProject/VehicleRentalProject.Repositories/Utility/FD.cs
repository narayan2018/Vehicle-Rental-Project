﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentalProject.Repositories.Utility
{
    public static class FD
    {
        public const string Admin_Role = "Admin";
        public const string Customer_Role = "Customer";
        public const string Admin_Role1 = "Admin1";

    }
}
