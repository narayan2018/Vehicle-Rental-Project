﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRentalProject.Repositories.DataSeeding
{
    public interface IDbInitializer
    {
        void Initialize();

    }
}
